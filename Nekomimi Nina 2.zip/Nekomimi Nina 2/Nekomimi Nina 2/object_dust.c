// Project Nonnon
// Project Nonnon
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#define N_OBJECT_DUST_SIZE  ( 24 )
#define N_OBJECT_DUST_COUNT ( 16 )




void
n_object_dust_kernel( n_nn2 *p, n_type_gfx x, n_type_gfx y )
{

	u32 color;
	u32 edge;

	// [x] : currently fuwafuwa is unused

	if ( p->fuwafuwa != 0 )
	{
		color = n_bmp_rgb_mac( 255,255,255 );
		edge  = n_bmp_rgb_mac( 222,222,222 );
	} else {
		color = n_bmp_rgb_mac( 222,222,222 );
		edge  = n_bmp_rgb_mac( 111,111,111 );
	}

	int i = 0;
	n_posix_loop
	{

		n_type_gfx sz = n_game_random( N_OBJECT_DUST_SIZE );
		n_type_gfx hf = sz / 2;

		n_type_gfx rx = n_game_random( hf );
		n_type_gfx ry = n_game_random( hf );

		n_bmp_circle( p->canvas, x + rx - hf, y + ry - hf, sz,sz,    color );
		n_bmp_hoop  ( p->canvas, x + rx - hf, y + ry - hf, sz,sz, 2, edge  );

		i++;
		if ( i >= N_OBJECT_DUST_COUNT ) { break; }
	}


	return;
}

void
n_object_dust_hipdrop_draw( n_nn2 *p )
{

	if ( p->swim_onoff ) { return; }

	if ( p->fuwafuwa != 0 ) { return; }


	if ( p->jump_state != N_NN2_JUMP_STATE_NONE ) { return; }

	if ( p->hipdrop_timer < n_posix_tickcount() ) { p->hipdrop_state = 3; return; }

	if ( p->hipdrop_state != 2 ) { return; }


	n_type_gfx lx,rx,y;

	const n_type_gfx offset = N_OBJECT_DUST_SIZE + 8;

	lx = p->stage->nina_x + p->nina_margin_rear - offset;
	rx = p->stage->nina_x + p->nina_sx - p->nina_margin_rear + offset - 16;

	 y = p->stage->nina_y + p->nina_sy - p->nina_margin_foot - ( N_OBJECT_DUST_SIZE / 2 );


	lx -= n_camerawork_x( p );
	rx -= n_camerawork_x( p );
	 y -= n_camerawork_y( p );


	n_object_dust_kernel( p, rx, y );
	n_object_dust_kernel( p, lx, y );


	return;
}

void
n_object_dust_dash_draw( n_nn2 *p )
{

	if ( p->swim_onoff ) { return; }

	if ( p->fuwafuwa != 0 ) { return; }


	n_type_gfx offset;

	if ( p->brake_phase )
	{
		offset = 0;
	} else {
		offset = 64 + 8;
	}


	n_type_gfx x,y;

	if ( p->direction == N_NN2_DIRECTION_LEFT )
	{
		x = p->stage->nina_x + p->nina_sx - p->nina_margin_rear + offset;
	} else {
		x = p->stage->nina_x + p->nina_margin_rear - offset - 16;
	}

	y = p->stage->nina_y + p->nina_sy - p->nina_margin_foot - N_OBJECT_DUST_SIZE;


	x -= n_camerawork_x( p );
	y -= n_camerawork_y( p );


	n_object_dust_kernel( p, x, y );


	return;
}

